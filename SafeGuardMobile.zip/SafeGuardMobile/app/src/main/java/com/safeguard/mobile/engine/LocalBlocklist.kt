package com.safeguard.mobile.engine

import java.time.LocalDate

data class BlocklistEntry(
    val domain: String,
    val category: ThreatCategory,
    val reason: String
)

/**
 * Simple local blocklist for offline protection.
 * Entries are clearly dated. Not a complete list of all threats.
 */
class LocalBlocklist {

    val lastUpdated: LocalDate = LocalDate.of(2026, 10, 1)

    // Example entries — in production load from assets or DataStore
    private val entries = listOf(
        BlocklistEntry("malware-example.com", ThreatCategory.MALWARE, "Known malware distribution"),
        BlocklistEntry("phishing-bank.com", ThreatCategory.PHISHING, "Phishing site impersonating bank"),
        BlocklistEntry("scam-download.net", ThreatCategory.FRAUD, "Fraudulent download page"),
        BlocklistEntry("gambling-site.example", ThreatCategory.GAMBLING, "Known gambling domain")
    )

    fun check(domain: String): BlocklistEntry? {
        val normalized = domain.lowercase().trimEnd('.')
        return entries.find { it.domain.equals(normalized, ignoreCase = true) ||
            normalized.endsWith(".${it.domain}") }
    }
}
