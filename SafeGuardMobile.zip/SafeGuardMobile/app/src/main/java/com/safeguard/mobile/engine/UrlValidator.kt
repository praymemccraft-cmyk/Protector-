package com.safeguard.mobile.engine

import java.net.IDN
import java.net.URI
import java.net.URISyntaxException
import java.util.Locale

/**
 * URL validation, normalization, and domain extraction.
 * Rejects unsafe schemes.
 */
object UrlValidator {

    private val ALLOWED_SCHEMES = setOf("http", "https")
    private val BLOCKED_SCHEMES = setOf("javascript", "file", "data", "intent", "market")

    data class ValidationResult(
        val isValid: Boolean,
        val normalizedUrl: String?,
        val domain: String?,
        val error: String?
    )

    fun validateAndNormalize(input: String?): ValidationResult {
        if (input.isNullOrBlank()) {
            return ValidationResult(false, null, null, "Empty input")
        }

        val trimmed = input.trim()
        return try {
            val uri = URI(trimmed)
            val scheme = uri.scheme?.lowercase(Locale.ROOT)

            if (scheme == null || scheme !in ALLOWED_SCHEMES) {
                if (scheme in BLOCKED_SCHEMES) {
                    return ValidationResult(false, null, null, "Unsafe scheme: $scheme")
                }
                return ValidationResult(false, null, null, "Unsupported or missing scheme")
            }

            val host = uri.host ?: return ValidationResult(false, null, null, "No host")
            val asciiHost = try {
                IDN.toASCII(host)
            } catch (e: Exception) {
                return ValidationResult(false, null, null, "Invalid domain")
            }

            val normalized = URI(scheme, uri.userInfo, asciiHost, uri.port, uri.path, uri.query, uri.fragment).toString()
            ValidationResult(true, normalized, asciiHost.lowercase(Locale.ROOT), null)
        } catch (e: URISyntaxException) {
            ValidationResult(false, null, null, "Malformed URL")
        }
    }

    fun extractDomain(url: String): String? = validateAndNormalize(url).domain
}
