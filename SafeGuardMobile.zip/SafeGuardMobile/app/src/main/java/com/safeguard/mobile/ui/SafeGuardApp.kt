package com.safeguard.mobile.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

enum class ProtectionState {
    OFF, STARTING, ACTIVE, LIMITED, ERROR
}

@Composable
fun SafeGuardApp() {
    var currentScreen by remember { mutableStateOf("dashboard") }
    var protectionState by remember { mutableStateOf(ProtectionState.OFF) }
    var statusMessage by remember { mutableStateOf("Protection is currently inactive.") }

    when (currentScreen) {
        "website" -> WebsiteScanScreen { currentScreen = "dashboard" }
        else -> Dashboard(
            protectionState = protectionState,
            statusMessage = statusMessage,
            onActivate = {
                protectionState = ProtectionState.STARTING
                statusMessage = "Starting foreground service..."
                // Real: ContextCompat.startForegroundService(context, Intent(context, ProtectionService::class.java))
                protectionState = ProtectionState.ACTIVE
                statusMessage = "Service running. Local blocklist active. VPN filtering requires consent."
            },
            onStop = {
                protectionState = ProtectionState.OFF
                statusMessage = "Protection stopped."
            },
            onScanWebsite = { currentScreen = "website" },
            onScanApk = { /* TODO: file picker */ },
            onHistory = { /* TODO */ },
            onSettings = { /* TODO */ }
        )
    }
}

@Composable
private fun Dashboard(
    protectionState: ProtectionState,
    statusMessage: String,
    onActivate: () -> Unit,
    onStop: () -> Unit,
    onScanWebsite: () -> Unit,
    onScanApk: () -> Unit,
    onHistory: () -> Unit,
    onSettings: () -> Unit
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("SafeGuard Mobile", fontWeight = FontWeight.Bold) },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer
                )
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Icon(
                imageVector = Icons.Default.Shield,
                contentDescription = "Shield",
                modifier = Modifier.size(80.dp),
                tint = MaterialTheme.colorScheme.primary
            )

            Text(
                text = when (protectionState) {
                    ProtectionState.OFF -> "PROTECTION OFF"
                    ProtectionState.STARTING -> "STARTING PROTECTION"
                    ProtectionState.ACTIVE -> "PROTECTION ACTIVE"
                    ProtectionState.LIMITED -> "LIMITED PROTECTION"
                    ProtectionState.ERROR -> "PROTECTION ERROR"
                },
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold,
                color = when (protectionState) {
                    ProtectionState.ACTIVE -> MaterialTheme.colorScheme.primary
                    ProtectionState.ERROR -> MaterialTheme.colorScheme.error
                    else -> MaterialTheme.colorScheme.onBackground
                }
            )

            Text(text = statusMessage, style = MaterialTheme.typography.bodyMedium)

            Spacer(modifier = Modifier.height(8.dp))

            if (protectionState == ProtectionState.OFF || protectionState == ProtectionState.ERROR) {
                Button(onClick = onActivate, modifier = Modifier.fillMaxWidth()) {
                    Text("ACTIVATE PROTECTION")
                }
            } else {
                Button(
                    onClick = onStop,
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("STOP PROTECTION")
                }
            }

            OutlinedButton(onClick = onScanWebsite, modifier = Modifier.fillMaxWidth()) {
                Text("Scan Website")
            }
            OutlinedButton(onClick = onScanApk, modifier = Modifier.fillMaxWidth()) {
                Text("Scan APK")
            }
            OutlinedButton(onClick = onHistory, modifier = Modifier.fillMaxWidth()) {
                Text("Scan History")
            }
            OutlinedButton(onClick = onSettings, modifier = Modifier.fillMaxWidth()) {
                Text("Security Settings")
            }
            TextButton(onClick = { /* Privacy screen */ }) {
                Text("Privacy Policy & Limitations")
            }
        }
    }
}
