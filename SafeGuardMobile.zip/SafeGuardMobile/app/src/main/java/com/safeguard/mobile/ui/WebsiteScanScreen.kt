package com.safeguard.mobile.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.safeguard.mobile.engine.DomainScanner
import com.safeguard.mobile.engine.ScanStatus
import kotlinx.coroutines.launch

@Composable
fun WebsiteScanScreen(onBack: () -> Unit) {
    var url by remember { mutableStateOf("") }
    var resultText by remember { mutableStateOf("") }
    var isScanning by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val scanner = remember { DomainScanner() }

    Column(Modifier.padding(16.dp)) {
        Text("Scan Website", style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(
            value = url,
            onValueChange = { url = it },
            label = { Text("Enter URL") },
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(8.dp))
        Button(
            onClick = {
                isScanning = true
                scope.launch {
                    val result = scanner.scan(url)
                    resultText = """
                        Status: ${result.status}
                        Reason: ${result.reason}
                        Sources: ${result.sources.joinToString()}
                        Complete: ${result.isComplete}
                        Recommendation: ${result.recommendation}
                    """.trimIndent()
                    isScanning = false
                }
            },
            enabled = !isScanning
        ) {
            Text(if (isScanning) "Scanning..." else "Scan")
        }
        Spacer(Modifier.height(16.dp))
        if (resultText.isNotEmpty()) {
            Text(resultText)
            if (resultText.contains("DANGEROUS")) {
                Text("SAFEGUARD SECURITY ALERT", color = MaterialTheme.colorScheme.error)
            }
        }
        TextButton(onClick = onBack) { Text("Back") }
    }
}
