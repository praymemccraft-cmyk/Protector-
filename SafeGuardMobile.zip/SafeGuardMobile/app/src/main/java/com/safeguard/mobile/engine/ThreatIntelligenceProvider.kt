package com.safeguard.mobile.engine

/**
 * Interface for optional remote threat intelligence.
 * Implementations must handle API keys securely (not hardcoded).
 * Prefer a backend proxy for private keys.
 */
interface ThreatIntelligenceProvider {
    suspend fun checkDomain(domain: String): ScanResult?
    suspend fun checkHash(sha256: String): ScanResult?
}
