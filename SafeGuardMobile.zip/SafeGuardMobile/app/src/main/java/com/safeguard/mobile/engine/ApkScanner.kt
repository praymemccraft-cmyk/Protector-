package com.safeguard.mobile.engine

import android.content.Context
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.net.Uri
import java.io.File
import java.security.MessageDigest

data class ApkScanResult(
    val status: ScanStatus,
    val sha256: String?,
    val packageName: String?,
    val versionName: String?,
    val permissions: List<String>,
    val suspiciousIndicators: List<String>,
    val reason: String,
    val recommendation: String
)

/**
 * Scans a user-selected APK file.
 * Never installs or executes the APK.
 * Calculates hash and performs basic static inspection.
 */
class ApkScanner(private val context: Context) {

    suspend fun scan(uri: Uri): ApkScanResult {
        return try {
            val inputStream = context.contentResolver.openInputStream(uri)
                ?: return failed("Could not open file")

            val bytes = inputStream.use { it.readBytes() }
            if (bytes.isEmpty()) return failed("Empty file")

            val sha256 = calculateSha256(bytes)

            // Basic package info (requires temporary copy or PackageManager on API 28+)
            val packageInfo = try {
                context.packageManager.getPackageArchiveInfo(
                    getFilePathFromUri(uri) ?: "",
                    PackageManager.GET_PERMISSIONS or PackageManager.GET_SIGNATURES
                )
            } catch (e: Exception) {
                null
            }

            val permissions = packageInfo?.requestedPermissions?.toList() ?: emptyList()
            val indicators = mutableListOf<String>()

            if (permissions.any { it.contains("SMS") || it.contains("CALL") }) {
                indicators.add("Requests sensitive SMS or call permissions")
            }
            if (permissions.contains("android.permission.SYSTEM_ALERT_WINDOW")) {
                indicators.add("Requests overlay permission")
            }

            val status = when {
                indicators.isNotEmpty() -> ScanStatus.SUSPICIOUS
                else -> ScanStatus.UNKNOWN
            }

            ApkScanResult(
                status = status,
                sha256 = sha256,
                packageName = packageInfo?.packageName,
                versionName = packageInfo?.versionName,
                permissions = permissions,
                suspiciousIndicators = indicators,
                reason = if (indicators.isEmpty()) "No obvious suspicious indicators from basic static analysis."
                         else "Suspicious indicators found.",
                recommendation = "Do not install untrusted APKs. Verify the source. Hash can be checked online if configured."
            )
        } catch (e: Exception) {
            failed("Scan error: ${e.message}")
        }
    }

    private fun calculateSha256(bytes: ByteArray): String {
        val digest = MessageDigest.getInstance("SHA-256")
        return digest.digest(bytes).joinToString("") { "%02x".format(it) }
    }

    private fun getFilePathFromUri(uri: Uri): String? {
        // SAF URI handling is more complex; this is simplified
        return if (uri.scheme == "file") uri.path else null
    }

    private fun failed(reason: String) = ApkScanResult(
        status = ScanStatus.FAILED,
        sha256 = null,
        packageName = null,
        versionName = null,
        permissions = emptyList(),
        suspiciousIndicators = emptyList(),
        reason = reason,
        recommendation = "Try selecting the file again."
    )
}
