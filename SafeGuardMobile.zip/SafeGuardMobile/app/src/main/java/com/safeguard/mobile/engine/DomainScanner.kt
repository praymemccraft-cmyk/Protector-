package com.safeguard.mobile.engine

import java.time.Instant

enum class ThreatCategory {
    MALWARE, PHISHING, FRAUD, GAMBLING, UNKNOWN, NONE
}

enum class ScanStatus {
    CLEAN, SUSPICIOUS, DANGEROUS, UNKNOWN, FAILED
}

data class ScanResult(
    val status: ScanStatus,
    val category: ThreatCategory,
    val reason: String,
    val sources: List<String>,
    val timestamp: Instant,
    val isComplete: Boolean,
    val recommendation: String
)

/**
 * Domain scanning engine.
 * Uses local blocklist + optional remote threat intelligence.
 * Never claims a site is safe just because it is not listed.
 */
class DomainScanner(
    private val localBlocklist: LocalBlocklist = LocalBlocklist(),
    private val remoteProvider: ThreatIntelligenceProvider? = null
) {

    suspend fun scan(url: String): ScanResult {
        val validation = UrlValidator.validateAndNormalize(url)
        if (!validation.isValid) {
            return ScanResult(
                status = ScanStatus.FAILED,
                category = ThreatCategory.UNKNOWN,
                reason = validation.error ?: "Invalid URL",
                sources = emptyList(),
                timestamp = Instant.now(),
                isComplete = false,
                recommendation = "Enter a valid http/https URL."
            )
        }

        val domain = validation.domain!!
        val localMatch = localBlocklist.check(domain)

        if (localMatch != null) {
            return ScanResult(
                status = ScanStatus.DANGEROUS,
                category = localMatch.category,
                reason = "Matched local blocklist entry: ${localMatch.reason}",
                sources = listOf("Local blocklist (${localBlocklist.lastUpdated})"),
                timestamp = Instant.now(),
                isComplete = true,
                recommendation = "Do not visit this site. Return to safety."
            )
        }

        // Optional remote check
        val remoteResult = remoteProvider?.checkDomain(domain)
        if (remoteResult != null) {
            return remoteResult
        }

        return ScanResult(
            status = ScanStatus.UNKNOWN,
            category = ThreatCategory.UNKNOWN,
            reason = "No known threats found in local blocklist. Online verification unavailable or not configured.",
            sources = listOf("Local blocklist"),
            timestamp = Instant.now(),
            isComplete = false,
            recommendation = "Exercise caution. Online threat intelligence was not available."
        )
    }
}
