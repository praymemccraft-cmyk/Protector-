package com.safeguard.mobile.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

val Context.dataStore by preferencesDataStore(name = "safeguard_prefs")

object PreferencesKeys {
    val LAST_SCAN = stringPreferencesKey("last_scan")
}

class ScanHistoryRepository(private val context: Context) {
    val lastScan: Flow<String?> = context.dataStore.data.map { it[PreferencesKeys.LAST_SCAN] }

    suspend fun saveLastScan(summary: String) {
        context.dataStore.edit { it[PreferencesKeys.LAST_SCAN] = summary }
    }

    suspend fun clearHistory() {
        context.dataStore.edit { it.remove(PreferencesKeys.LAST_SCAN) }
    }
}
