package com.safeguard.mobile.service

import android.app.Notification
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.safeguard.mobile.MainActivity
import com.safeguard.mobile.R
import com.safeguard.mobile.SafeGuardApplication

/**
 * Foreground service that keeps protection running in the background.
 * Performs periodic local blocklist checks and can coordinate with VPN filter.
 * Does NOT secretly monitor all traffic.
 */
class ProtectionService : Service() {

    private var isRunning = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (!isRunning) {
            startForeground(NOTIFICATION_ID, createNotification())
            isRunning = true
            // Start actual work: load local blocklist, schedule checks, etc.
            startProtectionWork()
        }
        return START_STICKY
    }

    override fun onDestroy() {
        isRunning = false
        super.onDestroy()
    }

    private fun startProtectionWork() {
        // Modular: delegate to engine
        // Example: periodically refresh local cache, listen for network changes
        android.util.Log.i("ProtectionService", "Protection work started. Local filtering active.")
    }

    private fun createNotification(): Notification {
        val pendingIntent = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        return NotificationCompat.Builder(this, SafeGuardApplication.CHANNEL_ID)
            .setContentTitle(getString(R.string.protection_notification_title))
            .setContentText(getString(R.string.protection_notification_text))
            .setSmallIcon(R.drawable.ic_shield)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    companion object {
        private const val NOTIFICATION_ID = 1001
    }
}
