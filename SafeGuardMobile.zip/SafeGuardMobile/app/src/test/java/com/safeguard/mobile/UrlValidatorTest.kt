package com.safeguard.mobile

import com.safeguard.mobile.engine.UrlValidator
import org.junit.Assert.*
import org.junit.Test

class UrlValidatorTest {

    @Test
    fun validHttpsUrl() {
        val result = UrlValidator.validateAndNormalize("https://example.com/path")
        assertTrue(result.isValid)
        assertEquals("example.com", result.domain)
    }

    @Test
    fun rejectsJavascriptScheme() {
        val result = UrlValidator.validateAndNormalize("javascript:alert(1)")
        assertFalse(result.isValid)
        assertTrue(result.error?.contains("Unsafe") == true || result.error?.contains("scheme") == true)
    }

    @Test
    fun rejectsEmpty() {
        val result = UrlValidator.validateAndNormalize("")
        assertFalse(result.isValid)
    }

    @Test
    fun handlesIdn() {
        val result = UrlValidator.validateAndNormalize("https://xn--n3h.com")
        assertTrue(result.isValid)
    }
}
