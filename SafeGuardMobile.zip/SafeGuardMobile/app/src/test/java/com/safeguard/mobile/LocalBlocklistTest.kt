package com.safeguard.mobile

import com.safeguard.mobile.engine.LocalBlocklist
import com.safeguard.mobile.engine.ThreatCategory
import org.junit.Assert.*
import org.junit.Test

class LocalBlocklistTest {

    private val blocklist = LocalBlocklist()

    @Test
    fun matchesKnownMalwareDomain() {
        val match = blocklist.check("malware-example.com")
        assertNotNull(match)
        assertEquals(ThreatCategory.MALWARE, match?.category)
    }

    @Test
    fun doesNotMatchCleanDomain() {
        val match = blocklist.check("google.com")
        assertNull(match)
    }
}
