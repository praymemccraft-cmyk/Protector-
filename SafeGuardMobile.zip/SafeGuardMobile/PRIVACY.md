# Privacy Policy — SafeGuard Mobile

Last updated: 2026-10-19

## What this app does

SafeGuard Mobile helps users check websites and APK files for known threats using local lists and optional external services.

## Data collection

- **Local only by default**: Scan history, blocklist matches, and protection status are stored on the device.
- **Optional remote checks**: If you configure a threat-intelligence provider, only the domain or file hash is sent. No full browsing history, passwords, or private messages are collected.
- No advertising SDKs.
- No analytics trackers.
- No collection of Telegram messages or private communications.

## Permissions

Permissions are requested only when needed and explained in the UI. VPN permission is required only for the optional filtering mode and is granted explicitly by the user through the Android system dialog.

## Third-party services

Any configured external service (Google Safe Browsing, VirusTotal, etc.) is subject to that provider’s own privacy policy. We recommend using a backend proxy so that API keys never leave your control.

## Clear history

A Clear History control will remove locally stored scan results.

## Contact

This is an educational / demonstration project. Review the source code for exact behavior.
