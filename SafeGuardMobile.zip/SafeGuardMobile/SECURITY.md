# Security Considerations — SafeGuard Mobile

## Design principles

- Honest about capabilities.
- Minimal permissions.
- No silent bypass of Android restrictions.
- No custom root certificates.
- No decryption of user traffic.
- Safe logging (no sensitive data).

## Threat model

The app aims to warn about *known* threats via blocklists and optional reputation services. It does not claim to detect novel malware or protect against all attack vectors.

## Reporting issues

If you discover a vulnerability in the source code, please open a private security advisory or contact the maintainers. Do not include real malware samples.

## False positives

Users can report false positives through the UI (implementation planned). Local rules can be adjusted.
