@rem Placeholder
gradle %*
