# SafeGuard Mobile

Persistent Android security and warning system for young users.

Helps protect against known malicious websites, phishing, fraudulent downloads, and suspicious APKs using local blocklists and optional threat intelligence.

**Important**: This is a practical first-release implementation. It does not claim 100% protection and honestly reports limitations.

## Main Features

- Dashboard with real protection status
- Foreground service for background protection (notification shown)
- Optional local VPN domain filtering (requires user VPN consent; limited by Android)
- Website URL scanning with validation and local blocklist
- APK scanning via Storage Access Framework (hash + basic static checks)
- Share intent support for Telegram / browser links
- Local scan history (planned extension)
- Privacy-focused: no unnecessary analytics or data collection

## Supported Android Versions

- Minimum: Android 10 (API 29)
- Target: API 35

## Required Permissions

- `INTERNET` / `ACCESS_NETWORK_STATE`: Optional remote reputation checks
- `FOREGROUND_SERVICE` + `FOREGROUND_SERVICE_SPECIAL_USE`: Persistent protection service
- `POST_NOTIFICATIONS`: Status notification
- `BIND_VPN_SERVICE`: Optional domain filtering VPN (user must approve)
- Share intents: Receive URLs and APKs shared by the user

## Setup and Build

1. Clone the repository.
2. Open in Android Studio (recommended) or use command line.
3. For API keys (optional): copy `.env.example` guidance into `local.properties` or CI secrets. Never commit real keys.
4. Generate full Gradle wrapper if needed:
   ```bash
   gradle wrapper --gradle-version 9.6.0
   ```
5. Build debug APK:
   ```bash
   ./gradlew assembleDebug
   ```
6. Run unit tests:
   ```bash
   ./gradlew test
   ```

### Building without a local computer

Push to GitHub. The included GitHub Actions workflow (`.github/workflows/android-build.yml`) will:

- Set up JDK and Android SDK
- Build the debug APK
- Run unit tests
- Upload the APK as an artifact

Download the artifact from the Actions tab after a successful run.

## How to Activate Protection

1. Open the app.
2. Tap **ACTIVATE PROTECTION**.
3. Grant notification permission if prompted.
4. If VPN filtering is enabled, approve the VPN connection dialog.
5. A persistent notification appears while the service is running.
6. Leave the app — the foreground service continues (subject to manufacturer battery optimizations).

Use **STOP PROTECTION** to stop the service.

## Testing Website Scanning

- Use the Scan Website button (UI navigation to be extended).
- Or share a link from Telegram/browser into SafeGuard.
- Valid examples: `https://example.com`
- Blocked example (local list): `https://malware-example.com`

Results clearly state sources and completeness.

## Testing APK Scanning

1. Download a known-safe APK (e.g., from official store, not malware).
2. Use Scan APK and select the file via the system picker.
3. Review hash and indicators.
4. Never install untrusted APKs based solely on this scan.

## Limitations (Honest)

- Cannot monitor every browser or intercept all traffic.
- VPN filter cannot decrypt HTTPS or see full page content.
- DNS-over-HTTPS and some encrypted protocols may bypass.
- Online checks require configured API keys or a backend proxy.
- Local blocklist is small and dated; not exhaustive.
- Some manufacturers aggressively kill background services.
- Does not install a custom root certificate or perform MITM.

See PRIVACY.md and SECURITY.md for more.

## Privacy

No browsing history is secretly collected. Domain checks (when online) send only the domain to the configured provider. See PRIVACY.md.

## Future Improvements

- Full navigation between screens
- Persistent local history with clear button
- Configurable categories
- Backend proxy example
- More comprehensive blocklists
- Better packet-level DNS filtering in VPN
- UI tests

## License

See LICENSE file.
